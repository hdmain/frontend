ALFAHOST.EU / ENGLISH GRAPHICS PACK

Open INDEX.html after extracting the ZIP. EDYTOR.html is a standalone offline text editor with PNG and SVG export. Its interface is in English. No text is uploaded to any server.

24 ENGLISH DESIGNS / PNG + SVG
01-hosted-by: 4 Hosted by badges.
02-server-runs-on: 4 This server runs on badges.
03-partners: banners at 728 x 90, 1200 x 400 and 1080 x 1080.
04-offers: Minecraft Starter, KVM VPS Netherlands and individual website hosting.
05-post-templates: promotion, new service and technical notice templates.
06-discord: a 960 x 540 banner, a 512 x 512 icon and four 960 x 240 headers: Plans, Support, Terms, Service status.
07-link-preview: a 1200 x 630 Open Graph image.
No tutorial graphics are included. Some logo-only or already-English badges are intentionally identical in both language packs.

All 24 designs have PNG and scalable SVG versions, for 48 primary image files. Badges and the 728 x 90 banner have double-resolution PNGs. Transparent-white is intended for dark backgrounds; transparent-black for light backgrounds.
The basic and extended Latin font subsets have been corrected. Fonts are embedded. Syne and Manrope licenses are included in licenses/.

BEFORE PUBLISHING
Fill in the bracketed fields. No discount, referral code, launch date, maintenance window or outage status has been invented. A banner does not activate a code or discount. The offline editor can remove TEMPLATE labels when exporting, but it does not automatically fill in missing fields.
Use hosting credits only on projects actually hosted by AlfaHost. The Service status header is a section label, not a live availability statement.

PRICES AND SERVICE DETAILS
This English edition uses US dollar (USD) prices read directly from AlfaHost with USD selected. No external exchange rate or manual currency conversion was used.
Minecraft Starter: USD 2.05 per month, 2 GB RAM, 10 GB NVMe, Warsaw, DDoS protection included.
VPS-1-NL: USD 4.48 per month, 2 vCore, 4 GB RAM, 75 GB SSD, public IPv4, 1 Gbit/s port, Netherlands.
USD prices and plan specifications were checked in the loaded product pages on 5 November 2026 (CET). Check current pricing, currency, availability and applicable taxes before publishing or ordering. The Polish edition is unchanged and remains in PLN.
Sources: https://alfahost.eu/en/offer/minecraft/ and https://alfahost.eu/en/offer/vps-kvm-nl/.
No net/gross tax label was added because it was not specified in the captured view.
Website hosting has no invented public plan or fixed price. Scope, limits, timing and pricing require individual agreement.

LINK PREVIEW
The Open Graph image is only a file. To change a live link preview, upload it to an accessible HTTPS URL and configure og:image and twitter:image. OG-METADANE.txt contains an example with a placeholder URL. Nothing has been deployed to the live website.

Brand horse, typography and red accent #EC2847 come from the AlfaHost frontend. This pack retains the same visual system as the corrected Polish edition.
