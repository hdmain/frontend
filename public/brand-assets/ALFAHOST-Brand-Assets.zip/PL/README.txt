ALFAHOST.EU / PAKIET 24 NOWYCH GRAFIK / WERSJA 2

Poprawiono osadzenie fontów Latin i Latin Extended we wszystkich PNG, SVG oraz w edytorze. Testy rzeczywiście użytych fontów w przeglądarce potwierdziły ten sam krój dla zwykłych liter, kompletu polskich znaków i zdań mieszanych, bez fontu zastępczego. Treści ofert i zakres paczki pozostają bez zmian.

Zacznij od INDEX.html. Otwórz plik w zwykłej przeglądarce po wypakowaniu ZIP.
EDYTOR.html działa offline i pozwala zmieniać kody, promocje, komunikaty oraz treści trzech ofert. Eksportuje PNG i SVG. Nie wysyła tekstu na żaden serwer.

ZAWARTOŚĆ
01-hosted-by: 4 stopki HOSTED BY / ALFAHOST.EU.
02-serwer-dziala-na: 4 stopki SERWER DZIAŁA NA / ALFAHOST.EU.
03-partnerzy: banery 728 x 90, 1200 x 400 i 1080 x 1080 z miejscem na kod.
04-oferty: 3 grafiki 1080 x 1080: Minecraft, VPS KVM, hosting stron.
05-posty-szablony: 3 szablony 1080 x 1080: promocja, nowa usługa, komunikat techniczny.
06-discord: baner 960 x 540, ikona 512 x 512 i 4 nagłówki 960 x 240: Oferta, Pomoc, Regulamin, Status usług.
07-podglad-linku: grafika Open Graph 1200 x 630.

Każdy projekt jest w PNG i SVG: łącznie 48 podstawowych plików graficznych.
Stopki i baner 728 x 90 mają PNG w podwójnej rozdzielczości. Pozostałe PNG mają rozdzielczość wskazaną w nazwie projektu.
Stopki transparent-white są do ciemnych stron; transparent-black do jasnych.
SVG mają osadzone fonty i pozostają skalowalne. Licencje fontów Syne i Manrope są w licenses/.
Nie ma grafik do poradników. Poprzednia paczka POWERED BY jest odrębnym zestawem.

CO UZUPEŁNIĆ PRZED PUBLIKACJĄ
Nie wymyślono rabatów, kodów, dat premier, prac technicznych ani stanu awarii. Pola w nawiasach kwadratowych uzupełnij w EDYTOR.html. Przy eksporcie edytor może usunąć oznaczenia SZABLON, ale nie usuwa automatycznie niewypełnionych pól.
Kody partnerów trzeba ustalić i uruchomić osobno. Sam baner nie tworzy kodu ani rabatu.
Oznaczeń HOSTED BY i SERWER DZIAŁA NA używaj dopiero wtedy, kiedy dany projekt jest faktycznie hostowany przez AlfaHost.
Nagłówek Status usług jest wyłącznie oznaczeniem sekcji, nie potwierdzeniem dostępności usług.

CENY I ŹRÓDŁA
Sprawdzono w działającym frontendzie 4 listopada 2026, strefa Europe/Warsaw.
Minecraft Starter: 8 zł/mies., 2 GB RAM, 10 GB NVMe, Warszawa, anty-DDoS.
Źródło: https://alfahost.eu/pl/offer/minecraft/
VPS-1-NL: 17,50 zł/mies., 2 vCore, 4 GB RAM, 75 GB SSD, publiczne IPv4, port 1 Gbit/s, Holandia.
Źródło: https://alfahost.eu/pl/offer/vps-kvm-nl/
Strona zbiorcza VPS pokazywała inną cenę startową. Do grafiki użyto ceny odczytanej po załadowaniu konkretnego planu VPS-1-NL. Przed publikacją oraz zamówieniem ponownie potwierdź cenę, walutę i dostępność.
Nie dodawano oznaczeń netto lub brutto, których nie podano w odczytanym widoku.
Hosting stron: brak publicznego pakietu WWW z parametrami i ceną w sprawdzonej ofercie. Grafika jest zaproszeniem do indywidualnych ustaleń, nie ofertą gotowego planu i nie obietnicą bezterminowego darmowego hostingu.

Logo konia i typografia pochodzą z frontendu https://alfahost.eu/; znak /icon.svg, fonty Syne i Manrope. Kolor akcentu #EC2847.

PODGLĄD LINKU
Sam obraz nie zmienia podglądu linku na Discordzie lub w mediach społecznościowych. Umieść og-1200x630.png pod publicznym adresem HTTPS i ustaw og:image oraz twitter:image w metadanych strony. W pliku OG-METADANE.txt jest przykład do uzupełnienia rzeczywistym adresem. Pamięć podręczna platform może wymagać odświeżenia.

Nie zmieniono frontendu AlfaHost, nie wgrano grafik na stronę i nie opublikowano żadnych postów.
