ALFAHOST.EU / PL: PLN / EN: USD

POLSKI
Otwórz INDEX.html po wypakowaniu całego ZIP i wybierz język.
PL: 24 projekty w PNG/SVG, bez zmian względem poprawionej polskiej wersji.
EN: 24 projekty w PNG/SVG, z cenami w USD w angielskich ofertach i edytorze.
Łącznie: 48 wersji graficznych, 96 podstawowych plików PNG/SVG.

Ceny EN odczytano bezpośrednio z załadowanych stron AlfaHost z wybraną walutą USD, 5 listopada 2026 (CET):
- Minecraft Starter: USD 2.05 / month.
- VPS-1-NL: USD 4.48 / month.
Źródła: https://alfahost.eu/en/offer/minecraft/ i https://alfahost.eu/en/offer/vps-kvm-nl/.
Nie zastosowano ręcznego przeliczenia kursu. Polska wersja pozostaje w PLN.
Hosting stron nadal ma warunki i wycenę do indywidualnego ustalenia, bez wymyślonej ceny.
Sprawdź aktualną cenę i dostępność przed publikacją. Szablony rabatów, kodów i dat wymagają uzupełnienia. Niczego nie opublikowano na stronie.

ENGLISH
Extract the full ZIP, open INDEX.html and choose a language.
PL: 24 designs in PNG/SVG, unchanged from the corrected Polish edition.
EN: 24 designs in PNG/SVG, with USD prices in the English offers and offline editor.
Total: 48 language versions, 96 primary PNG/SVG files.

USD prices were read directly from the loaded AlfaHost product pages with USD selected on 5 November 2026 (CET):
- Minecraft Starter: USD 2.05 per month.
- VPS-1-NL: USD 4.48 per month.
No manual currency conversion was used. The Polish edition remains in PLN. Website hosting still requires individual terms and pricing.
Verify current pricing and availability before publishing. Fill in template fields first. Nothing has been deployed to the live website.

CONTENTS.json lists primary image paths, dimensions and SHA-256 hashes.
